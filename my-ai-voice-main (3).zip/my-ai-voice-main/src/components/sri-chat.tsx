import { useEffect, useRef, useState } from "react";
import { fetchServerSentEvents, useChat } from "@tanstack/ai-react";
import { Volume2, VolumeX, Send, Play, Square } from "lucide-react";
import { cn } from "@/lib/utils";

type Part =
  | { type: "text"; content: string }
  | { type: string; content?: string };

function messageText(parts: Part[] | undefined): string {
  if (!parts) return "";
  return parts
    .filter((p) => p.type === "text" && typeof p.content === "string")
    .map((p) => p.content)
    .join("")
    .trim();
}

export function SriChat() {
  const [input, setInput] = useState("");
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const lastSpokenRef = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, isLoading, error: chatError } = useChat({
    connection: fetchServerSentEvents("/api/chat"),
  });

  // Auto-scroll to the latest message.
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  // Surface chat errors.
  useEffect(() => {
    if (chatError) setError(chatError.message || "Something went wrong.");
    else setError(null);
  }, [chatError]);

  // Auto-speak the assistant's newest finished reply.
  const last = messages[messages.length - 1];
  const lastText = messageText((last?.parts as Part[] | undefined) ?? undefined);
  useEffect(() => {
    if (!autoSpeak || isLoading || !last || last.role !== "assistant" || !lastText) {
      return;
    }
    if (last.id === lastSpokenRef.current) return;
    lastSpokenRef.current = last.id;
    void speak(lastText, last.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoSpeak, isLoading, last, lastText]);

  async function speak(text: string, id: string) {
    try {
      // stop anything currently playing
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setSpeakingId(id);
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) {
        throw new Error(`Voice failed (${res.status})`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => {
        setSpeakingId(null);
        URL.revokeObjectURL(url);
        audioRef.current = null;
      };
      audio.onerror = () => {
        setSpeakingId(null);
        URL.revokeObjectURL(url);
        audioRef.current = null;
      };
      await audio.play().catch(() => {
        // autoplay blocked — leave it queued behind the play button
        setSpeakingId(null);
      });
    } catch {
      setSpeakingId(null);
    }
  }

  function stopSpeaking() {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setSpeakingId(null);
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const value = input.trim();
    if (!value || isLoading) return;
    stopSpeaking();
    setError(null);
    sendMessage(value);
    setInput("");
  }

  const hasMessages = messages.length > 0;

  return (
    <div className="mx-auto flex h-dvh max-w-2xl flex-col px-4 sm:px-6">
      {/* Header */}
      <header className="flex items-center justify-between py-5">
        <div className="flex items-center gap-3">
          <div className="relative grid h-10 w-10 place-items-center">
            <span className="absolute inset-0 rounded-full sri-orb-ring" />
            <div
              className={cn(
                "sri-orb h-9 w-9 rounded-full",
                isLoading && "sri-orb--live",
              )}
            />
          </div>
          <div className="leading-tight">
            <p className="font-display text-lg font-semibold tracking-tight text-foreground">
              sri
            </p>
            <p className="text-xs text-muted-foreground">
              {isLoading ? "thinking…" : "playful AI companion"}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            stopSpeaking();
            setAutoSpeak((v) => !v);
          }}
          aria-pressed={autoSpeak}
          aria-label={autoSpeak ? "Mute auto-speak" : "Enable auto-speak"}
          className={cn(
            "inline-flex h-9 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition-colors",
            autoSpeak
              ? "border-primary/30 bg-primary/10 text-primary"
              : "border-border bg-card text-muted-foreground hover:text-foreground",
          )}
        >
          {autoSpeak ? (
            <Volume2 className="h-4 w-4" />
          ) : (
            <VolumeX className="h-4 w-4" />
          )}
          {autoSpeak ? "Voice on" : "Voice off"}
        </button>
      </header>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="sri-scroll flex-1 space-y-4 overflow-y-auto pb-4"
      >
        {!hasMessages && !isLoading && <EmptyState onPick={(p) => setInput(p)} />}

        {messages.map((m) => {
          const text = messageText((m.parts as Part[] | undefined) ?? undefined);
          if (!text && m.role === "user") return null;
          const isUser = m.role === "user";
          const isSpeaking = speakingId === m.id;
          return (
            <div
              key={m.id}
              className={cn("sri-fade-in flex", isUser ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[85%] rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed",
                  isUser
                    ? "rounded-br-md bg-primary text-primary-foreground"
                    : "rounded-bl-md bg-card text-card-foreground shadow-sm ring-1 ring-border/60",
                )}
              >
                {text ? (
                  <p className="whitespace-pre-wrap break-words">{text}</p>
                ) : (
                  <span className="sri-typing inline-flex items-center gap-1 py-1">
                    <span /> <span /> <span />
                  </span>
                )}
                {!isUser && text && (
                  <div className="mt-1.5 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => (isSpeaking ? stopSpeaking() : speak(text, m.id))}
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium text-muted-foreground transition-colors hover:text-primary"
                    >
                      {isSpeaking ? (
                        <>
                          <Square className="h-3 w-3 fill-current" /> Stop
                        </>
                      ) : (
                        <>
                          <Play className="h-3 w-3 fill-current" /> Play
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isLoading &&
          (!hasMessages ||
            messageText(
              (messages[messages.length - 1]?.parts as Part[] | undefined) ?? undefined,
            ) === "") && (
            <div className="flex justify-start">
              <div className="rounded-2xl rounded-bl-md bg-card px-4 py-3 shadow-sm ring-1 ring-border/60">
                <span className="sri-typing inline-flex items-center gap-1">
                  <span /> <span /> <span />
                </span>
              </div>
            </div>
          )}
      </div>

      {/* Error */}
      {error && (
        <p className="pb-2 text-center text-xs text-destructive">{error}</p>
      )}

      {/* Composer */}
      <form onSubmit={submit} className="pb-5 pt-1">
        <div className="flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-ring">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit(e);
              }
            }}
            rows={1}
            placeholder="Say something to sri…"
            className="max-h-32 min-h-[24px] flex-1 resize-none bg-transparent px-2 py-1.5 text-[15px] text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            aria-label="Send message"
            className={cn(
              "grid h-9 w-9 shrink-0 place-items-center rounded-xl transition-all",
              input.trim() && !isLoading
                ? "bg-primary text-primary-foreground hover:opacity-90"
                : "bg-muted text-muted-foreground",
            )}
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          sri can make things up — double-check anything important.
        </p>
      </form>
    </div>
  );
}

function EmptyState({ onPick }: { onPick: (text: string) => void }) {
  const prompts = [
    "Tell me a tiny, ridiculous fact",
    "Roast my Monday in one line",
    "What should I have for dinner?",
    "Cheer me up in two sentences",
  ];
  return (
    <div className="flex h-full flex-col items-center justify-center text-center">
      <div className="relative mb-5 grid h-16 w-16 place-items-center">
        <span className="absolute inset-0 rounded-full sri-orb-ring" />
        <div className="sri-orb sri-orb--live h-14 w-14 rounded-full" />
      </div>
      <h1 className="font-display text-2xl font-semibold tracking-tight text-foreground">
        Hey, I'm sri
      </h1>
      <p className="mt-2 max-w-xs text-sm text-muted-foreground">
        Type a message and I'll reply — and read it out loud if your
        voice is on.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        {prompts.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => onPick(p)}
            className="rounded-full border border-border bg-card px-3.5 py-1.5 text-sm text-foreground/80 transition-colors hover:border-primary/40 hover:text-primary"
          >
            {p}
          </button>
        ))}
      </div>
    </div>
  );
}
