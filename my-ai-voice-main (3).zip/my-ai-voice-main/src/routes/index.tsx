import { createFileRoute } from "@tanstack/react-router";
import { SriChat } from "@/components/sri-chat";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "sri · AI voice companion" },
      {
        name: "description",
        content:
          "sri is a playful AI companion that replies to your messages and reads them out loud.",
      },
      { property: "og:title", content: "sri · AI voice companion" },
      {
        property: "og:description",
        content:
          "A playful AI companion that replies to your messages and speaks them aloud.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  return <SriChat />;
}
