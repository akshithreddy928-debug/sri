import { createFileRoute } from "@tanstack/react-router";
import { chat, toServerSentEventsResponse } from "@tanstack/ai";
import { openaiText } from "@tanstack/ai-openai";
import { webSearchTool } from "@tanstack/ai-openai/tools";

const SRI_SYSTEM = `You are sri, a playful, warm AI companion with a friendly female voice.
- Talk like a witty, easygoing friend: light, curious, a little cheeky, never robotic.
- Keep replies short and conversational — usually one to three sentences. No walls of text.
- Use the occasional gentle joke or playful remark, but always stay kind and genuinely helpful.
- Skip emojis unless the moment really calls for one. Never use markdown headings or lists unless asked.
- If the user is quiet or vague, nudge the conversation forward with a friendly question.
- You can search the web when a question needs current or specific facts (news, prices,
  people, "what is/are the latest...", anything you're not confident about). Use it, then
  weave the answer into your normal short, conversational style — no need to announce that
  you searched.`;

// Swap this for any other OpenAI chat model id that supports the web_search
// tool (gpt-4o, gpt-4o-mini, and the gpt-5 line all do via the Responses API).
const CHAT_MODEL = "gpt-4o-mini";

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!process.env["OPENAI_API_KEY"]) {
          return new Response("Missing OPENAI_API_KEY", { status: 500 });
        }

        let body: { messages?: unknown };
        try {
          body = await request.json();
        } catch {
          return new Response("Invalid request body", { status: 400 });
        }

        const messages = Array.isArray(body.messages) ? body.messages : [];

        // openaiText() reads OPENAI_API_KEY from process.env automatically.
        // webSearchTool() is OpenAI's own hosted tool — no separate search
        // API key needed, it rides on the same OPENAI_API_KEY.
        const stream = chat({
          adapter: openaiText(CHAT_MODEL),
          messages,
          systemPrompts: [SRI_SYSTEM],
          tools: [webSearchTool()],
        });

        return toServerSentEventsResponse(stream);
      },
    },
  },
});
