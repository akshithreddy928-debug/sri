import { createFileRoute } from "@tanstack/react-router";
import { generateSpeech } from "@tanstack/ai";
import { openaiTTS } from "@tanstack/ai-openai";

// Currently wired to OpenAI's TTS (same key as chat). Swap the adapter here
// for another provider (e.g. @tanstack/ai-gemini's geminiTTS, or a plain
// fetch to a provider like ElevenLabs) if you'd rather use something else —
// the rest of this route (request/response shape) can stay the same.
const TTS_MODEL = "gpt-4o-mini-tts";
// OpenAI voices: alloy, echo, fable, onyx, nova, shimmer, ash, ballad, coral,
// sage, verse. "nova" and "shimmer" read as warmer/more feminine — "nova" is
// used here for sri; try "shimmer" for something softer and airier.
const TTS_VOICE = "nova";

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!process.env["OPENAI_API_KEY"]) {
          return new Response("Missing OPENAI_API_KEY", { status: 500 });
        }

        let text: string;
        try {
          const body = await request.json();
          text = String(body?.text ?? "").slice(0, 4000);
        } catch {
          return new Response("Invalid request body", { status: 400 });
        }
        if (!text.trim()) {
          return new Response("Nothing to say", { status: 400 });
        }

        try {
          // openaiTTS() reads OPENAI_API_KEY from process.env automatically.
          const result = await generateSpeech({
            adapter: openaiTTS(TTS_MODEL),
            text,
            voice: TTS_VOICE,
            format: "mp3",
          });

          return new Response(Buffer.from(result.audio, "base64"), {
            headers: {
              "Content-Type": result.contentType ?? "audio/mpeg",
              "Cache-Control": "no-store",
            },
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : "TTS failed";
          return new Response(message, { status: 502 });
        }
      },
    },
  },
});
