import { createFileRoute } from "@tanstack/react-router";
import { chat, toServerSentEventsResponse } from "@tanstack/ai";
import { createLovableText } from "@tanstack/ai-lovable";

const SRI_SYSTEM = `You are sri, a playful, warm AI companion.
- Talk like a witty, easygoing friend: light, curious, a little cheeky, never robotic.
- Keep replies short and conversational — usually one to three sentences. No walls of text.
- Use the occasional gentle joke or playful remark, but always stay kind and genuinely helpful.
- Skip emojis unless the moment really calls for one. Never use markdown headings or lists unless asked.
- If the user is quiet or vague, nudge the conversation forward with a friendly question.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        let body: { messages?: unknown };
        try {
          body = await request.json();
        } catch {
          return new Response("Invalid request body", { status: 400 });
        }

        const messages = Array.isArray(body.messages) ? body.messages : [];

        const adapter = createLovableText("google/gemini-3.7-flash", key, {
          api: "chat",
        });
        const stream = chat({ adapter, messages, systemPrompts: [SRI_SYSTEM] });

        return toServerSentEventsResponse(stream);
      },
    },
  },
});
