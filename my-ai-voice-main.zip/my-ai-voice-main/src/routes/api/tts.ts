import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        let text: string;
        try {
          const body = await request.json();
          text = String(body?.text ?? "").slice(0, 4000);
        } catch {
          return new Response("Invalid request body", { status: 400 });
        }
        if (!text.trim()) {
          return new Response("Nothing to say", { status: 400 });
        }

        const response = await fetch(
          "https://ai.gateway.lovable.dev/v1/audio/speech",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${key}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "openai/gpt-4o-mini-tts",
              input: text,
              voice: "alloy",
              response_format: "mp3",
              stream_format: "audio",
            }),
          },
        );

        if (!response.ok) {
          const detail = await response.text().catch(() => "");
          return new Response(detail || `TTS failed: ${response.status}`, {
            status: response.status,
          });
        }

        return new Response(response.body, {
          headers: {
            "Content-Type": "audio/mpeg",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
